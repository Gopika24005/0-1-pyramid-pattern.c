#include<stdio.h>
int main()
{
    int n,i,j,a;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        a=i;
        for(j=i;j<n;j++)
           printf(" ");
        for(j=1;j<=i;j++){
            printf("%d ",a++%2);
        }
        printf("\n");
    }
    return 0;
}